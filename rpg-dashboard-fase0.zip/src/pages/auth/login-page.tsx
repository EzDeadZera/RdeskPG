import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'

// Formulário funcional (validação, cadastro, recuperação de senha, resolução
// username -> e-mail) chega na Fase 1. Por enquanto isso só mostra o layout.
export function LoginPage() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Entrar</CardTitle>
        <CardDescription>Login e cadastro chegam na Fase 1.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="username">Usuário</Label>
          <Input id="username" placeholder="seu-usuario" disabled />
        </div>
        <div className="space-y-2">
          <Label htmlFor="password">Senha</Label>
          <Input id="password" type="password" placeholder="••••••••" disabled />
        </div>
        <Button className="w-full" disabled>
          Entrar (Fase 1)
        </Button>
      </CardContent>
    </Card>
  )
}
